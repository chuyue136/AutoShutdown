; ============================================================
; 自动关机助手 - Inno Setup 安装包脚本
; 适用项目：WPF APP (.NET 10 WPF, 框架依赖部署)
; ============================================================

[Setup]
; ---------- 基本信息 ----------
AppName=自动关机助手
AppVersion=1.0.0
AppPublisher=chuyue136

; ---------- 安装路径 ----------
; 用户级安装：装到当前用户的 AppData\Local\Programs 下，不需要管理员权限
; （如果想装到 C:\Program Files 给所有用户用，改成 {autopf}\AutoShutdown，
;   并把下面的 PrivilegesRequired 改回 admin，同时把 {userstartup} 改成 {commonstartup}）
DefaultDirName={userpf}\AutoShutdown
DefaultGroupName=自动关机助手
DisableProgramGroupPage=yes

; ---------- 安装包输出 ----------
OutputDir=.\installer
OutputBaseFilename=AutoShutdown_Setup_v1.0.0

; ---------- 压缩 ----------
Compression=lzma2
SolidCompression=yes

; ---------- 图标 ----------
; 使用项目根目录的 icon.ico 作为安装包图标
SetupIconFile=.\icon.ico
UninstallDisplayIcon={app}\WPF APP.exe

; ---------- 权限 ----------
; 用户级安装用 lowest，不需要管理员权限，不弹 UAC
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog

; ---------- 其他 ----------
RestartIfNeededByRun=no
WizardStyle=modern
; 安装向导左侧大图（没有可注释掉）
; WizardImageFile=.\wizard_image.bmp
; WizardSmallImageFile=.\wizard_small_image.bmp


; ============================================================
; 安装类型（完整 / 自定义）
; ============================================================
[Types]
Name: "full"; Description: "完整安装"
Name: "custom"; Description: "自定义安装"; Flags: iscustom


; ============================================================
; 组件（可选功能）
; ============================================================
[Components]
Name: "main"; Description: "主程序"; Types: full custom; Flags: fixed
Name: "desktopicon"; Description: "桌面快捷方式"; Types: full custom; Flags: checkablealone
; 注意：不提供安装包层面的开机自启，由软件内部设置控制（写注册表），避免重复启动


; ============================================================
; 要打包的文件（Release 文件夹全部内容）
; ============================================================
[Files]
; 打包 Release 文件夹下的所有文件和子文件夹
; recursesubdirs  = 递归子目录（Assets、runtimes 等）
; createallsubdirs = 自动创建子目录
; ignoreversion    = 忽略版本号，覆盖安装
Source: "Release\*"; DestDir: "{app}"; Components: main; Flags: recursesubdirs createallsubdirs ignoreversion

; 可选：排除调试符号文件（.pdb）和 XML 文档，减小体积
; 如需排除，把上面那行注释掉，改用下面这两行：
; Source: "Release\*"; DestDir: "{app}"; Components: main; Flags: recursesubdirs createallsubdirs ignoreversion; Excludes: "*.pdb,*.xml"
; Source: "Release\*.pdb"; DestDir: "{app}"; Components: main; Flags: recursesubdirs createallsubdirs ignoreversion; onlyifdoesntexist


; ============================================================
; 快捷方式
; ============================================================
[Icons]
; 开始菜单
Name: "{group}\自动关机助手"; Filename: "{app}\WPF APP.exe"; Components: main
Name: "{group}\卸载自动关机助手"; Filename: "{uninstallexe}"; Components: main

; 桌面快捷方式（可选组件）
Name: "{autodesktop}\自动关机助手"; Filename: "{app}\WPF APP.exe"; Components: desktopicon; IconFilename: "{app}\WPF APP.exe"

; 开机自启由软件内部设置控制，不在安装包创建启动项，避免与软件自身的开机自启冲突


; ============================================================
; 安装完成后运行
; ============================================================
[Run]
; 安装完成后弹出"立即运行"勾选框
Filename: "{app}\WPF APP.exe"; Description: "立即运行自动关机助手"; Flags: nowait postinstall skipifsilent


; ============================================================
; 卸载时删除的额外内容
; ============================================================
[UninstallDelete]
; 注意：默认不删除用户数据（%AppData%\AutoShutdown），保留配置和日志
; 如果想卸载时一并删除用户数据，取消下面这行的注释：
; Type: filesandordirs; Name: "{userappdata}\AutoShutdown"

; 开机自启由软件内部写注册表实现，卸载时软件自身的卸载逻辑会清理（如未清理，可在软件设置中关闭自启后再卸载）


; ============================================================
; 安装前检测 .NET 桌面运行时
; （本项目是框架依赖部署，用户机器必须安装 .NET 桌面运行时）
; ============================================================
[Code]
function IsDotNetDesktopRuntimeInstalled(): Boolean;
var
  Version: String;
begin
  Result := False;
  { 检测 .NET 桌面运行时是否安装（检查注册表） }
  if RegQueryStringValue(HKEY_LOCAL_MACHINE,
     'SOFTWARE\dotnet\Setup\InstalledVersions\x64\sharedfx\Microsoft.WindowsDesktop.App',
     'Version', Version) then
  begin
    { 如果版本号存在，认为已安装 }
    if Version <> '' then
      Result := True;
  end;
end;

function InitializeSetup(): Boolean;
var
  ResultCode: Integer;
begin
  Result := True;
  { 安装前检测 .NET 桌面运行时 }
  if not IsDotNetDesktopRuntimeInstalled() then
  begin
    if MsgBox('检测到您的电脑尚未安装 .NET 桌面运行时，本软件无法运行。' + #13#10 + #13#10 +
              '是否现在打开下载页面？' + #13#10 +
              '（下载后安装 "桌面运行时 Desktop Runtime" 版本）',
              mbConfirmation, MB_YESNO) = IDYES then
    begin
      { 打开 .NET 10 下载页面 }
      ShellExec('open', 'https://dotnet.microsoft.com/download/dotnet/10.0',
                 '', '', SW_SHOWNORMAL, ewNoWait, ResultCode);
    end;
    { 无论用户选是或否，都允许继续安装（安装后用户再装运行时也行） }
    { 如果想强制要求安装运行时，把下面这行改成 Result := False; }
    Result := True;
  end;
end;
