using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace WPF_APP.Models
{
    /// <summary>
    /// 单日关机计划：时间 + 是否启用（需求 4.3）。
    /// 默认全部启用、默认时间 22:30。支持属性变更通知，便于界面双向绑定。
    /// </summary>
    public class DaySchedule : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler? PropertyChanged;

        public DayOfWeek Day { get; set; }

        private TimeSpan _time = new TimeSpan(22, 30, 0);

        public TimeSpan Time
        {
            get => _time;
            set
            {
                if (_time == value) return;
                _time = value;
                OnPropertyChanged(nameof(Time));
                OnPropertyChanged(nameof(Hour));
                OnPropertyChanged(nameof(Minute));
            }
        }

        private bool _isEnabled = true;

        public bool IsEnabled
        {
            get => _isEnabled;
            set
            {
                if (_isEnabled == value) return;
                _isEnabled = value;
                OnPropertyChanged();
            }
        }

        /// <summary>时（0-23），供时间选择器绑定。</summary>
        public int Hour
        {
            get => Time.Hours;
            set
            {
                if (value != Time.Hours)
                    Time = new TimeSpan(value, Time.Minutes, 0);
            }
        }

        /// <summary>分（0-59），供时间选择器绑定。</summary>
        public int Minute
        {
            get => Time.Minutes;
            set
            {
                if (value != Time.Minutes)
                    Time = new TimeSpan(Time.Hours, value, 0);
            }
        }

        /// <summary>星期标签，如"周一"。</summary>
        public string WeekdayLabel => "周" + "日一二三四五六"[(int)Day];

        private void OnPropertyChanged([CallerMemberName] string? name = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}
