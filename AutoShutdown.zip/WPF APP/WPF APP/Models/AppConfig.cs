using WPF_APP.Services;

namespace WPF_APP.Models
{
    /// <summary>
    /// 全局配置（需求 5.1），序列化到 %AppData%\AutoShutdown\config.json。
    /// </summary>
    public class AppConfig
    {
        public List<DayScheduleConfig> Days { get; set; } = new();

        /// <summary>再提醒时长（分钟）。</summary>
        public int ReminderMinutes { get; set; } = 10;

        /// <summary>弹窗倒计时（秒）。</summary>
        public int CountdownSeconds { get; set; } = 30;

        /// <summary>提示音预设。</summary>
        public SoundPreset SoundPreset { get; set; } = SoundPreset.Soft;

        /// <summary>自定义音频文件路径（为空则使用预设）。</summary>
        public string? CustomSoundPath { get; set; }

        /// <summary>音量（0-100）。</summary>
        public int Volume { get; set; } = 80;

        /// <summary>"今日不再关机"置位的日期；跨天后自动失效。</summary>
        public DateTime? SkippedDate { get; set; }

        /// <summary>已执行关机的历史时间戳（用于"今日/本周已执行关机"统计，跨重启保留）。</summary>
        public List<DateTime> ShutdownHistory { get; set; } = new();
    }

    /// <summary>单日关机计划（序列化形态）。</summary>
    public class DayScheduleConfig
    {
        public DayOfWeek Day { get; set; }

        public int Hour { get; set; } = 22;

        public int Minute { get; set; } = 30;

        public bool IsEnabled { get; set; } = true;
    }
}
