namespace WPF_APP
{
    /// <summary>
    /// 时/分候选值（时间选择器与批量设置弹窗共用）。
    /// </summary>
    public static class TimeItems
    {
        public static int[] Hours { get; } = Enumerable.Range(0, 24).ToArray();

        public static int[] Minutes { get; } = Enumerable.Range(0, 60).ToArray();
    }
}
