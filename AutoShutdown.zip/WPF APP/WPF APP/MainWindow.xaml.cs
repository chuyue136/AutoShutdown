using System.Collections.Generic;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Animation;
using System.Windows.Threading;
using WPF_APP.Services;
using WPF_APP.Views.Pages;

namespace WPF_APP
{
    /// <summary>
    /// 主页窗口：自定义标题栏 + 左侧导航 + 内容区页面切换。
    /// 关闭窗口即真正销毁窗口并释放页面资源（程序仍驻留托盘），再次打开时重建；
    /// 彻底退出需通过托盘右键菜单。
    /// </summary>
    public partial class MainWindow : Window
    {
        private const double PaneExpandedWidth = 148;
        private const double PaneCollapsedWidth = 60;

        private readonly Dictionary<string, UserControl> _pages = new();
        private readonly Dictionary<RadioButton, TextBlock> _navLabels = new();
        private bool _paneExpanded = true;

        public MainWindow()
        {
            InitializeComponent();
            Icon = AppIconFactory.CreateImageSource();

            _pages["概览"] = new OverviewPage();
            _pages["定时设置"] = new SchedulePage();
            _pages["提醒设置"] = new ReminderPage();
            _pages["关于"] = new AboutPage();
            PageHost.Content = _pages["概览"];

            Loaded += OnLoaded;
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            CacheNavLabel(NavOverview);
            CacheNavLabel(NavSchedule);
            CacheNavLabel(NavReminder);
            CacheNavLabel(NavAbout);
        }

        private void CacheNavLabel(RadioButton item)
        {
            if (item.Template?.FindName("PART_Label", item) is TextBlock label)
                _navLabels[item] = label;
        }

        private void SwitchPage(RadioButton item)
        {
            if (PageHost is null) return;
            var key = NavItem.GetLabel(item);
            if (_pages.TryGetValue(key, out var page))
                PageHost.Content = page;
        }

        private void NavItem_Checked(object sender, RoutedEventArgs e)
        {
            if (PageHost is null) return; // 初始化阶段（PageHost 尚未创建）时忽略
            SetPaneExpanded(true);
            SwitchPage((RadioButton)sender);
        }

        private void NavPane_MouseEnter(object sender, MouseEventArgs e) => SetPaneExpanded(true);

        private void NavPane_MouseLeave(object sender, MouseEventArgs e) => SetPaneExpanded(false);

        private void SetPaneExpanded(bool expand)
        {
            if (_paneExpanded == expand) return;
            _paneExpanded = expand;

            var anim = new DoubleAnimation(expand ? PaneExpandedWidth : PaneCollapsedWidth,
                                           TimeSpan.FromMilliseconds(200))
            {
                EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseOut }
            };
            NavPane.BeginAnimation(FrameworkElement.WidthProperty, anim);

            foreach (var label in _navLabels.Values)
                label.Visibility = expand ? Visibility.Visible : Visibility.Collapsed;
        }

        // ---- 标题栏交互 ----
        private void TitleBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.OriginalSource is Button) return; // 让按钮自己响应点击
            if (e.ClickCount == 2)
            {
                ToggleMaximize();
                return;
            }
            DragMove();
        }

        private void MinButton_Click(object sender, RoutedEventArgs e)
            => WindowState = WindowState.Minimized;

        private void MaxButton_Click(object sender, RoutedEventArgs e)
            => ToggleMaximize();

        private void CloseButton_Click(object sender, RoutedEventArgs e)
            => Close();

        private void ToggleMaximize()
            => WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;

        private void Window_StateChanged(object sender, EventArgs e)
        {
            bool max = WindowState == WindowState.Maximized;
            RootBorder.Margin = max ? new Thickness(0) : new Thickness(16);
            RootBorder.CornerRadius = max ? new CornerRadius(0) : new CornerRadius(8);
            MaxButton.Content = max ? "\uE923" : "\uE922";
            MaxButton.ToolTip = max ? "还原" : "最大化";
        }

        private void Window_Closing(object? sender, CancelEventArgs e)
        {
            // 关闭前释放页面资源（WebView2 浏览器进程），避免内存常驻
            DisposePageResources();
        }

        private void Window_Closed(object? sender, EventArgs e)
        {
            // 窗口真正销毁后延迟触发一次垃圾回收，尽快把主窗口占用的内存归还系统
            Dispatcher.BeginInvoke(new Action(() =>
            {
                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }), DispatcherPriority.Background);
        }

        private void DisposePageResources()
        {
            if (_pages.TryGetValue("关于", out var page) && page is AboutPage about)
                about.DisposeWebView();
        }
    }
}
