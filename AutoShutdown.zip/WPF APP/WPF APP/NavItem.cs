using System.Windows;

namespace WPF_APP
{
    /// <summary>
    /// 为导航按钮附加"图标字形"与"文字标签"两个属性，
    /// 供导航样式模板绑定使用。
    /// </summary>
    public static class NavItem
    {
        public static readonly DependencyProperty GlyphProperty = DependencyProperty.RegisterAttached(
            "Glyph", typeof(string), typeof(NavItem), new PropertyMetadata(string.Empty));

        public static string GetGlyph(DependencyObject obj) => (string)obj.GetValue(GlyphProperty);
        public static void SetGlyph(DependencyObject obj, string value) => obj.SetValue(GlyphProperty, value);

        public static readonly DependencyProperty LabelProperty = DependencyProperty.RegisterAttached(
            "Label", typeof(string), typeof(NavItem), new PropertyMetadata(string.Empty));

        public static string GetLabel(DependencyObject obj) => (string)obj.GetValue(LabelProperty);
        public static void SetLabel(DependencyObject obj, string value) => obj.SetValue(LabelProperty, value);
    }
}
