using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Gdi = System.Drawing;

namespace WPF_APP.Services
{
    /// <summary>
    /// 在运行时生成应用图标（蓝色圆形 + 白色电源符号），
    /// 避免依赖外部 .ico 资源文件。
    /// </summary>
    internal static class AppIconFactory
    {
        [DllImport("user32.dll")]
        private static extern bool DestroyIcon(IntPtr hIcon);

        [DllImport("gdi32.dll")]
        private static extern bool DeleteObject(IntPtr hObject);

        private static Gdi.Bitmap RenderBitmap(int size)
        {
            var bmp = new Gdi.Bitmap(size, size);
            using var g = Gdi.Graphics.FromImage(bmp);
            g.SmoothingMode = Gdi.Drawing2D.SmoothingMode.AntiAlias;
            g.Clear(Gdi.Color.Transparent);

            using (var bg = new Gdi.SolidBrush(Gdi.Color.FromArgb(255, 0, 120, 212)))
            {
                g.FillEllipse(bg, 0, 0, size, size);
            }

            using (var font = new Gdi.Font("Segoe MDL2 Assets", size * 0.55f,
                                           Gdi.FontStyle.Regular, Gdi.GraphicsUnit.Pixel))
            using (var fg = new Gdi.SolidBrush(Gdi.Color.White))
            {
                g.TextRenderingHint = Gdi.Text.TextRenderingHint.AntiAliasGridFit;
                const string glyph = "\uE7E8"; // 电源符号
                var sz = g.MeasureString(glyph, font);
                g.DrawString(glyph, font, fg, (size - sz.Width) / 2f, (size - sz.Height) / 2f - 1f);
            }

            return bmp;
        }

        /// <summary>托盘图标（System.Drawing.Icon）。</summary>
        public static Gdi.Icon CreateIcon()
        {
            using var bmp = RenderBitmap(32);
            var hIcon = bmp.GetHicon();
            try
            {
                using var icon = Gdi.Icon.FromHandle(hIcon);
                return (Gdi.Icon)icon.Clone();
            }
            finally
            {
                DestroyIcon(hIcon);
            }
        }

        /// <summary>窗口任务栏图标（WPF ImageSource）。</summary>
        public static ImageSource CreateImageSource()
        {
            using var bmp = RenderBitmap(32);
            var hBitmap = bmp.GetHbitmap();
            try
            {
                return Imaging.CreateBitmapSourceFromHBitmap(
                    hBitmap, IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromWidthAndHeight(32, 32));
            }
            finally
            {
                DeleteObject(hBitmap);
            }
        }
    }
}
