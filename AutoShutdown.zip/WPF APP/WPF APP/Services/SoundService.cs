using System.IO;
using System.Media;
using System.Windows.Media;

namespace WPF_APP.Services
{
    /// <summary>
    /// 提示音播放：预设音（程序目录 Assets\sounds\ 下的 wav 文件）+ 自定义音频文件（.wav/.mp3）。
    /// 播放失败静默忽略，不影响主流程（需求 5.3）。
    /// </summary>
    public static class SoundService
    {
        private static MediaPlayer? _mediaPlayer;

        /// <summary>播放"当前生效"的提示音：自定义文件优先，否则使用预设。</summary>
        public static void PlayEffective(ReminderService settings)
        {
            if (!string.IsNullOrEmpty(settings.CustomSoundPath) && File.Exists(settings.CustomSoundPath))
            {
                PlayFile(settings.CustomSoundPath, settings.Volume);
                return;
            }
            PlayPreset(settings.SoundPreset, settings.Volume);
        }

        public static void PlayPreset(SoundPreset preset, int volumePercent = 100)
        {
            switch (preset)
            {
                case SoundPreset.Soft:
                    PlayFile(GetPresetPath("柔和提示音.wav"), volumePercent);
                    break;
                case SoundPreset.Chime:
                    PlayFile(GetPresetPath("清脆铃声.wav"), volumePercent);
                    break;
                case SoundPreset.Beep:
                    PlayFile(GetPresetPath("电子蜂鸣.wav"), volumePercent);
                    break;
                case SoundPreset.SystemDefault:
                    SystemSounds.Asterisk.Play();
                    break;
                case SoundPreset.Mute:
                    break;
            }
        }

        private static string GetPresetPath(string fileName)
            => Path.Combine(AppContext.BaseDirectory, "Assets", "sounds", fileName);

        private static void PlayFile(string path, int volumePercent)
        {
            try
            {
                if (!File.Exists(path)) return;

                _mediaPlayer?.Close();
                _mediaPlayer = new MediaPlayer
                {
                    Volume = Math.Clamp(volumePercent, 0, 100) / 100.0
                };
                _mediaPlayer.Open(new Uri(path, UriKind.Absolute));
                _mediaPlayer.Play();
            }
            catch
            {
                // 播放失败静默处理（需求 5.3）
            }
        }
    }
}
