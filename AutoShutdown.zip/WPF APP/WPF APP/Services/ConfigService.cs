using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Windows.Threading;
using WPF_APP.Models;

namespace WPF_APP.Services
{
    /// <summary>
    /// 配置持久化（需求 5.1 / 5.3）：
    /// 所有设置自动写入 %AppData%\AutoShutdown\config.json，修改后即时生效、写入带 500ms 防抖；
    /// 配置损坏时备份损坏文件并回退默认值启动。
    /// </summary>
    public sealed class ConfigService : IDisposable
    {
        private static readonly string ConfigDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "AutoShutdown");
        private static readonly string ConfigPath = Path.Combine(ConfigDir, "config.json");

        private static readonly JsonSerializerOptions JsonOptions = new()
        {
            WriteIndented = true,
            Converters = { new JsonStringEnumConverter() }
        };

        private readonly ScheduleService _scheduler = ScheduleService.Instance;
        private readonly ReminderService _reminder = ReminderService.Instance;
        private readonly DispatcherTimer _debounce = new() { Interval = TimeSpan.FromMilliseconds(500) };
        private bool _dirty;
        private bool _loading;

        public ConfigService()
        {
            Load();

            _debounce.Tick += (_, _) => Flush();

            foreach (var day in _scheduler.Days)
                day.PropertyChanged += (_, _) => ScheduleSave();
            _scheduler.PropertyChanged += (_, _) => ScheduleSave();
            _reminder.PropertyChanged += (_, _) => ScheduleSave();
        }

        public void Dispose()
        {
            _debounce.Stop();
            if (_dirty) Flush();
        }

        private void ScheduleSave()
        {
            if (_loading) return;
            _dirty = true;
            _debounce.Stop();
            _debounce.Start(); // 500ms 防抖，避免频繁 IO
        }

        private void Flush()
        {
            _debounce.Stop();
            if (!_dirty) return;
            _dirty = false;

            try
            {
                var config = new AppConfig
                {
                    Days = _scheduler.Days.Select(d => new DayScheduleConfig
                    {
                        Day = d.Day,
                        Hour = d.Time.Hours,
                        Minute = d.Time.Minutes,
                        IsEnabled = d.IsEnabled
                    }).ToList(),
                    ReminderMinutes = _reminder.ReminderMinutes,
                    CountdownSeconds = _reminder.CountdownSeconds,
                    SoundPreset = _reminder.SoundPreset,
                    CustomSoundPath = _reminder.CustomSoundPath,
                    Volume = _reminder.Volume,
                    SkippedDate = _scheduler.TodaySkipped ? DateTime.Today : null,
                    ShutdownHistory = _scheduler.ShutdownHistory.ToList()
                };

                Directory.CreateDirectory(ConfigDir);
                File.WriteAllText(ConfigPath, JsonSerializer.Serialize(config, JsonOptions));
            }
            catch
            {
                // 写失败静默处理（日志后续接入）
            }
        }

        private void Load()
        {
            try
            {
                if (!File.Exists(ConfigPath)) return; // 无配置文件，使用默认值

                var json = File.ReadAllText(ConfigPath);
                var config = JsonSerializer.Deserialize<AppConfig>(json, JsonOptions);
                if (config is null)
                {
                    BackupCorrupt();
                    return;
                }

                _loading = true;
                try
                {
                    Apply(config);
                }
                finally
                {
                    _loading = false;
                }
            }
            catch
            {
                // 配置损坏（需求 5.3）：备份损坏文件，使用默认配置启动
                BackupCorrupt();
            }
        }

        private void BackupCorrupt()
        {
            try
            {
                if (File.Exists(ConfigPath))
                    File.Copy(ConfigPath, ConfigPath + ".bak", overwrite: true);
            }
            catch
            {
                // 备份失败静默处理
            }
        }

        private void Apply(AppConfig config)
        {
            foreach (var item in config.Days ?? new List<DayScheduleConfig>())
            {
                var sched = _scheduler.Days.FirstOrDefault(d => d.Day == item.Day);
                if (sched is null) continue;
                sched.IsEnabled = item.IsEnabled;
                sched.Time = new TimeSpan(item.Hour, item.Minute, 0);
            }

            _reminder.ReminderMinutes = config.ReminderMinutes;
            _reminder.CountdownSeconds = config.CountdownSeconds;
            _reminder.SoundPreset = config.SoundPreset;
            _reminder.CustomSoundPath = config.CustomSoundPath;
            _reminder.Volume = config.Volume;

            // "今日不再关机"仅当天有效，跨天自动失效
            _scheduler.TodaySkipped = config.SkippedDate == DateTime.Today;
        }
    }
}
