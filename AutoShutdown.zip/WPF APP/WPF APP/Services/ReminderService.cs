using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace WPF_APP.Services
{
    /// <summary>提示音预设类型。</summary>
    public enum SoundPreset
    {
        Soft,          // 柔和提示音
        Chime,         // 清脆铃声
        Beep,          // 电子蜂鸣
        SystemDefault, // 系统默认
        Mute           // 静音
    }

    /// <summary>
    /// 提醒行为与提示音设置（需求 4.4）。
    /// 注意：后续轮次将接入配置持久化（%AppData%\AutoShutdown\config.json）。
    /// </summary>
    public sealed class ReminderService : INotifyPropertyChanged
    {
        public static ReminderService Instance { get; } = new();

        private ReminderService() { }

        private int _reminderMinutes = 10;

        /// <summary>再提醒时长（分钟），范围 1-120，默认 10。</summary>
        public int ReminderMinutes
        {
            get => _reminderMinutes;
            set
            {
                value = Math.Clamp(value, 1, 120);
                if (_reminderMinutes == value) return;
                _reminderMinutes = value;
                OnPropertyChanged();
            }
        }

        private int _countdownSeconds = 30;

        /// <summary>弹窗倒计时（秒），范围 5-300，默认 30。</summary>
        public int CountdownSeconds
        {
            get => _countdownSeconds;
            set
            {
                value = Math.Clamp(value, 5, 300);
                if (_countdownSeconds == value) return;
                _countdownSeconds = value;
                OnPropertyChanged();
            }
        }

        private SoundPreset _soundPreset = SoundPreset.Soft;

        /// <summary>提示音预设。</summary>
        public SoundPreset SoundPreset
        {
            get => _soundPreset;
            set
            {
                if (_soundPreset == value) return;
                _soundPreset = value;
                OnPropertyChanged();
            }
        }

        private string? _customSoundPath;

        /// <summary>自定义音频文件路径（为空则使用预设）。</summary>
        public string? CustomSoundPath
        {
            get => _customSoundPath;
            set
            {
                if (_customSoundPath == value) return;
                _customSoundPath = value;
                OnPropertyChanged();
            }
        }

        private int _volume = 80;

        /// <summary>音量（0-100），默认 80。</summary>
        public int Volume
        {
            get => _volume;
            set
            {
                value = Math.Clamp(value, 0, 100);
                if (_volume == value) return;
                _volume = value;
                OnPropertyChanged();
            }
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        private void OnPropertyChanged([CallerMemberName] string? name = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}
