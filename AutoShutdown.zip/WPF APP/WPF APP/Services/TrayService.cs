using System.Windows;
using WPF_APP.Views;
using WinForms = System.Windows.Forms;

namespace WPF_APP.Services
{
    /// <summary>
    /// 系统托盘：软件启动后在通知区域显示图标。
    /// 双击图标打开主页；右键菜单（需求 3.3）：立即关机 / 今日不再关机 / 进入主页 / 退出自动关机。
    /// </summary>
    public sealed class TrayService : IDisposable
    {
        private WinForms.NotifyIcon? _notifyIcon;
        private bool _disposed;

        public void Initialize()
        {
            var menu = new WinForms.ContextMenuStrip();

            // 需求 3.3-1：立即关机（弹二次确认，需求 3.4）
            var shutdownItem = new WinForms.ToolStripMenuItem("立即关机");
            shutdownItem.Click += (_, _) => ShutdownWithConfirm();

            // 需求 3.3-2：今日不再关机
            var skipItem = new WinForms.ToolStripMenuItem("今日不再关机");
            skipItem.Click += (_, _) => ScheduleService.Instance.TodaySkipped = true;

            // 需求 3.3-3：进入主页
            var homeItem = new WinForms.ToolStripMenuItem("进入主页");
            homeItem.Click += (_, _) => ShowMainWindow();

            // 需求 3.3-4：退出自动关机
            var exitItem = new WinForms.ToolStripMenuItem("退出自动关机");
            exitItem.Click += (_, _) => ExitApp();

            menu.Items.Add(shutdownItem);
            menu.Items.Add(skipItem);
            menu.Items.Add(homeItem);
            menu.Items.Add(new WinForms.ToolStripSeparator());
            menu.Items.Add(exitItem);

            _notifyIcon = new WinForms.NotifyIcon
            {
                Icon = AppIconFactory.CreateIcon(),
                Text = "自动关机助手",
                ContextMenuStrip = menu,
                Visible = true
            };
            _notifyIcon.MouseDoubleClick += OnTrayMouseDoubleClick;
        }

        private static void ShutdownWithConfirm()
        {
            var dispatcher = Application.Current.Dispatcher;
            if (!dispatcher.CheckAccess())
            {
                dispatcher.Invoke(ShutdownWithConfirm);
                return;
            }

            // 需求 3.4：二次确认，防止误触
            var owner = Application.Current.Windows.OfType<MainWindow>().FirstOrDefault(w => w.IsVisible);
            var confirm = new ConfirmShutdownWindow { Owner = owner };
            confirm.ShowDialog();
            if (!confirm.Confirmed) return;

            if (ShutdownService.ExecuteShutdown())
                ScheduleService.Instance.RegisterShutdownExecuted(DateTime.Now);
        }

        private static void OnTrayMouseDoubleClick(object? sender, WinForms.MouseEventArgs e)
        {
            if (e.Button != WinForms.MouseButtons.Left)
                return;
            ShowMainWindow();
        }

        /// <summary>打开（或新建并显示）主页窗口。</summary>
        internal static void ShowMainWindow()
        {
            var window = Application.Current.Windows.OfType<MainWindow>().FirstOrDefault();
            if (window is null)
                window = new MainWindow();

            window.Show();
            if (window.WindowState == WindowState.Minimized)
                window.WindowState = WindowState.Normal;
            window.Activate();
        }

        private static void ExitApp()
        {
            // 主窗口平时关闭即销毁；退出时直接关闭整个应用
            Application.Current.Shutdown();
        }

        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;
            _notifyIcon?.Dispose();
            _notifyIcon = null;
        }
    }
}
