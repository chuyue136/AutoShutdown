using System.Diagnostics;

namespace WPF_APP.Services
{
    /// <summary>
    /// 执行系统关机，使用 shutdown /s /t 0（需求 5.8）。
    /// </summary>
    public static class ShutdownService
    {
        public static bool ExecuteShutdown()
        {
            try
            {
                var psi = new ProcessStartInfo("shutdown", "/s /t 0")
                {
                    CreateNoWindow = true,
                    UseShellExecute = false
                };
                using var process = Process.Start(psi);
                return true;
            }
            catch (Exception ex)
            {
                // 需求 5.3：失败不静默，提示用户（日志功能后续接入）
                System.Windows.MessageBox.Show(
                    $"关机命令执行失败：{ex.Message}",
                    "自动关机助手",
                    System.Windows.MessageBoxButton.OK,
                    System.Windows.MessageBoxImage.Error);
                return false;
            }
        }
    }
}
