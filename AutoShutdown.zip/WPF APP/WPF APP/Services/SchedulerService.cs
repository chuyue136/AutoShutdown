using System.Windows;
using System.Windows.Threading;
using Microsoft.Win32;
using WPF_APP.Views;

namespace WPF_APP.Services
{
    /// <summary>
    /// 核心调度（需求 1.1 / 第二章）：每天到达用户设定的关机时间时，弹出关机提醒窗口。
    /// 每秒检查一次；若当天计划禁用或已"今日不再关机"则不触发。
    /// 处理"X 分钟后再提醒"延迟（需求 2.3）与休眠/唤醒（需求 5.5）。
    /// </summary>
    public sealed class SchedulerService : IDisposable
    {
        public static SchedulerService Instance { get; } = new();

        private readonly ScheduleService _scheduler = ScheduleService.Instance;
        private readonly ReminderService _reminder = ReminderService.Instance;
        private readonly Dispatcher _dispatcher;

        private readonly DispatcherTimer _timer = new() { Interval = TimeSpan.FromSeconds(1) };
        private ReminderWindow? _activeWindow;
        private DateTime? _delayUntil;

        private SchedulerService()
        {
            _dispatcher = Application.Current.Dispatcher;
            _timer.Tick += OnTick;
            SystemEvents.PowerModeChanged += OnPowerModeChanged;
        }

        /// <summary>
        /// 下一次关机提醒触发时间（主页倒计时的唯一权威来源）：
        /// 处于"X 分钟后再提醒"等待期时为其结束时刻，否则为按每日计划计算的下一次关机时刻。
        /// </summary>
        public DateTime? NextTriggerTime
        {
            get
            {
                if (_delayUntil is DateTime d) return d;
                return _scheduler.GetNextShutdownTime();
            }
        }

        public void Start() => _timer.Start();

        public void Dispose()
        {
            _timer.Stop();
            SystemEvents.PowerModeChanged -= OnPowerModeChanged;
        }

        private void OnTick(object? sender, EventArgs e)
        {
            if (_activeWindow is not null) return; // 提醒弹窗已打开，等待处理

            if (_delayUntil is DateTime d)
            {
                if (DateTime.Now < d) return;      // 仍在"再提醒"等待期
                _delayUntil = null;

                // 需求 2.3：再提醒时长到，直接重新弹出提醒（倒计时重置）
                // 延迟期间若已"今日不再关机"，则当天不再触发
                if (_scheduler.TodaySkipped) return;
                ShowReminder();
                return;
            }

            if (IsTriggerMoment())
                ShowReminder();
        }

        /// <summary>
        /// 当前是否处于"今日设定关机时刻"的触发窗口（到达设定时刻后的 1 分钟内），
        /// 每天实时计算，天然兼容计划修改、今日跳过与休眠唤醒。
        /// </summary>
        private bool IsTriggerMoment()
        {
            var today = _scheduler.GetTodaySchedule();
            if (today is null || !today.IsEnabled || _scheduler.TodaySkipped)
                return false;

            var scheduled = DateTime.Today.Add(today.Time);
            var now = DateTime.Now;
            return now >= scheduled && now < scheduled.AddMinutes(1);
        }

        private void ShowReminder()
        {
            var window = new ReminderWindow();
            _activeWindow = window;
            window.Closed += (_, _) =>
            {
                _activeWindow = null;
                OnReminderClosed(window);
            };
            window.Show();
        }

        private void OnReminderClosed(ReminderWindow window)
        {
            switch (window.Result)
            {
                case ReminderWindow.ReminderResult.Delay:
                    // 需求 2.3：经过设定时长后重新弹出提醒
                    _delayUntil = DateTime.Now.AddMinutes(_reminder.ReminderMinutes);
                    break;
                case ReminderWindow.ReminderResult.SkipToday:
                    // 需求 2.4：今日不再触发（TodaySkipped 已由弹窗置位，IsTriggerMoment 自动失效）
                    _delayUntil = null;
                    break;
                default:
                    _delayUntil = null;
                    break;
            }
        }

        private void OnPowerModeChanged(object sender, PowerModeChangedEventArgs e)
        {
            // SystemEvents 事件可能不在 UI 线程触发，统一调度到 UI 线程
            if (!_dispatcher.CheckAccess())
            {
                _dispatcher.BeginInvoke(new Action(() => OnPowerModeChanged(sender, e)));
                return;
            }

            if (e.Mode == PowerModes.Suspend)
            {
                // 即将休眠：停止计时，并关闭正在显示的提醒弹窗，防止休眠期间触发关机
                _timer.Stop();
                _activeWindow?.ForceClose(ReminderWindow.ReminderResult.None);
            }
            else if (e.Mode == PowerModes.Resume)
            {
                // 唤醒后重新按实际时间判断是否立即触发（IsTriggerMoment 每秒实时计算）
                _delayUntil = null;
                _timer.Start();
            }
        }
    }
}
