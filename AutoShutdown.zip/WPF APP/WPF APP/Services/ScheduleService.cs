using System.ComponentModel;
using WPF_APP.Models;

namespace WPF_APP.Services
{
    /// <summary>
    /// 每日关机计划与今日运行状态。
    /// 数据由 ConfigService 持久化到 %AppData%\AutoShutdown\config.json。
    /// </summary>
    public sealed class ScheduleService : INotifyPropertyChanged
    {
        public static ScheduleService Instance { get; } = new();

        /// <summary>一周七天（周一至周日）的关机计划。</summary>
        public IReadOnlyList<DaySchedule> Days { get; }

        private bool _todaySkipped;

        /// <summary>今日已跳过（点击"今日不再关机"后为 true）。</summary>
        public bool TodaySkipped
        {
            get => _todaySkipped;
            set
            {
                if (_todaySkipped == value) return;
                _todaySkipped = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(TodaySkipped)));
            }
        }

        private readonly List<DateTime> _shutdownHistory = new();

        /// <summary>已执行关机的时间戳历史（由 ConfigService 持久化，跨重启保留）。</summary>
        public IReadOnlyList<DateTime> ShutdownHistory => _shutdownHistory;

        /// <summary>今日已执行关机的次数。</summary>
        public int ExecutedTodayCount { get; private set; }

        /// <summary>本周（周一为起点）已执行关机次数。</summary>
        public int ExecutedThisWeekCount { get; private set; }

        /// <summary>一次关机已执行（通知持久化立即落盘，避免系统关机前丢失本次记录）。</summary>
        public event Action? ShutdownRecorded;

        private ScheduleService()
        {
            // 按周一至周日顺序排列
            var list = new List<DaySchedule>();
            for (int i = 0; i < 7; i++)
            {
                var day = (DayOfWeek)(((int)DayOfWeek.Monday + i) % 7);
                list.Add(new DaySchedule { Day = day });
            }
            Days = list;
        }

        public DaySchedule? GetTodaySchedule()
            => Days.FirstOrDefault(d => d.Day == DateTime.Today.DayOfWeek);

        /// <summary>
        /// 计算下一次关机时间：从今天起向后找第一个"已启用"的计划；
        /// 若今天已执行"今日不再关机"，则跳过今天（需求 1.1 / 2.4）。
        /// </summary>
        public DateTime? GetNextShutdownTime()
        {
            var now = DateTime.Now;
            for (int i = 0; i < 8; i++)
            {
                var day = now.Date.AddDays(i);
                var sched = Days.FirstOrDefault(d => d.Day == day.DayOfWeek);
                if (sched is null || !sched.IsEnabled) continue;
                if (i == 0 && TodaySkipped) continue;

                var t = day.Add(sched.Time);
                if (t > now) return t;
            }
            return null;
        }

        /// <summary>恢复历史记录（启动时由 ConfigService 调用）；只保留近 30 天，避免配置无限膨胀。</summary>
        public void SetShutdownHistory(IEnumerable<DateTime> history)
        {
            var cutoff = DateTime.Today.AddDays(-30);
            _shutdownHistory.Clear();
            _shutdownHistory.AddRange(history.Where(h => h >= cutoff).OrderBy(h => h));
            RecomputeCounts();
        }

        private void RecomputeCounts()
        {
            var today = DateTime.Today;
            var monday = today.AddDays(-(((int)today.DayOfWeek + 6) % 7));
            ExecutedTodayCount = _shutdownHistory.Count(h => h.Date == today);
            ExecutedThisWeekCount = _shutdownHistory.Count(h => h.Date >= monday);
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ExecutedTodayCount)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ExecutedThisWeekCount)));
        }

        /// <summary>记录一次关机执行（更新今日/本周统计，并通知立即持久化）。</summary>
        public void RegisterShutdownExecuted(DateTime time)
        {
            _shutdownHistory.Add(time);
            RecomputeCounts();
            ShutdownRecorded?.Invoke();
        }

        public event PropertyChangedEventHandler? PropertyChanged;
    }
}
