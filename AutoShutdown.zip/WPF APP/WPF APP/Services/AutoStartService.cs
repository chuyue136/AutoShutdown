using Microsoft.Win32;

namespace WPF_APP.Services
{
    /// <summary>
    /// 开机自动启动（需求 5.4）：
    /// 通过注册表 HKCU\Software\Microsoft\Windows\CurrentVersion\Run 实现，无需管理员权限。
    /// </summary>
    public static class AutoStartService
    {
        private const string RunKeyPath = @"Software\Microsoft\Windows\CurrentVersion\Run";
        private const string ValueName = "AutoShutdown";

        public static bool IsEnabled()
        {
            try
            {
                using var key = Registry.CurrentUser.OpenSubKey(RunKeyPath);
                return key?.GetValue(ValueName) is string value && !string.IsNullOrEmpty(value);
            }
            catch
            {
                return false;
            }
        }

        public static void Enable()
        {
            try
            {
                using var key = Registry.CurrentUser.CreateSubKey(RunKeyPath);
                key?.SetValue(ValueName, $"\"{Environment.ProcessPath}\"");
            }
            catch
            {
                // 写入失败静默处理
            }
        }

        public static void Disable()
        {
            try
            {
                using var key = Registry.CurrentUser.OpenSubKey(RunKeyPath, writable: true);
                key?.DeleteValue(ValueName, throwOnMissingValue: false);
            }
            catch
            {
                // 删除失败静默处理
            }
        }
    }
}
