using System.Threading;
using System.Windows;
using WPF_APP.Services;
using WPF_APP.Views;

namespace WPF_APP
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private const string SingleInstanceMutexName = "Global\\AutoShutdown.SingleInstance";

        private TrayService? _tray;
        private SchedulerService? _scheduler;
        private ConfigService? _config;
        private Mutex? _singleInstanceMutex;

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            // 单实例保护：程序已在运行时，再次启动只弹提示窗并退出
            if (!AcquireSingleInstance())
            {
                var notice = new SingleInstanceWindow();
                notice.ShowDialog();
                Shutdown();
                return;
            }

            // 先加载持久化配置（所有设置写入 %AppData%\AutoShutdown\config.json）
            _config = new ConfigService();

            // 启动系统托盘图标
            _tray = new TrayService();
            _tray.Initialize();

            // 启动定时调度（每天到点弹出关机提醒）
            _scheduler = SchedulerService.Instance;
            _scheduler.Start();

            // 启动后仅驻留系统托盘，主页通过双击托盘图标或右键"进入主页"打开
        }

        protected override void OnExit(ExitEventArgs e)
        {
            _config?.Dispose();
            _scheduler?.Dispose();
            _tray?.Dispose();

            ReleaseSingleInstance();
            base.OnExit(e);
        }

        /// <summary>
        /// 获取单实例互斥锁。若已有运行中的实例返回 false；
        /// 前一个实例异常退出（abandoned）时由本实例接管，避免误报。
        /// </summary>
        private bool AcquireSingleInstance()
        {
            _singleInstanceMutex = new Mutex(true, SingleInstanceMutexName, out bool createdNew);
            if (createdNew) return true;

            bool acquired;
            try
            {
                acquired = _singleInstanceMutex.WaitOne(0);
            }
            catch (AbandonedMutexException)
            {
                acquired = true; // 接管异常退出的上一个实例
            }

            if (!acquired)
            {
                _singleInstanceMutex.Dispose();
                _singleInstanceMutex = null;
                return false;
            }
            return true;
        }

        private void ReleaseSingleInstance()
        {
            if (_singleInstanceMutex is null) return;
            try
            {
                _singleInstanceMutex.ReleaseMutex();
            }
            catch
            {
                // 未持有互斥锁时忽略
            }
            _singleInstanceMutex.Dispose();
            _singleInstanceMutex = null;
        }
    }
}
