// 项目同时启用了 WPF 与 WinForms（WinForms 仅用于系统托盘图标）。
// 消除两类同名类型的歧义。
global using Application = System.Windows.Application;
global using UserControl = System.Windows.Controls.UserControl;
global using RadioButton = System.Windows.Controls.RadioButton;
global using Button = System.Windows.Controls.Button;
global using MouseEventArgs = System.Windows.Input.MouseEventArgs;
global using KeyEventArgs = System.Windows.Input.KeyEventArgs;
global using Brush = System.Windows.Media.Brush;
global using Color = System.Windows.Media.Color;
