using System.Windows;
using System.Windows.Input;

namespace WPF_APP.Views
{
    /// <summary>
    /// 二次确认关机弹窗（需求 3.4）。
    /// </summary>
    public partial class ConfirmShutdownWindow : Window
    {
        /// <summary>用户是否确认关机。</summary>
        public bool Confirmed { get; private set; }

        public ConfirmShutdownWindow()
        {
            InitializeComponent();
        }

        private void Confirm_Click(object sender, RoutedEventArgs e)
        {
            Confirmed = true;
            Close();
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
            => Close();

        private void Window_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
                Close();
        }
    }
}
