using System.Windows;

namespace WPF_APP.Views
{
    /// <summary>
    /// 单实例提示窗：程序已在运行时再次启动，提示用户不要启动多个进程。
    /// </summary>
    public partial class SingleInstanceWindow : Window
    {
        public SingleInstanceWindow()
        {
            InitializeComponent();
        }

        private void Close_Click(object sender, RoutedEventArgs e)
            => Close();
    }
}
