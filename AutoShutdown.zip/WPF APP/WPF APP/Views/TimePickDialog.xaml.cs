using System.Windows;
using System.Windows.Input;

namespace WPF_APP.Views
{
    /// <summary>
    /// 时间选择弹窗（时:分），供"批量设置"等场景复用。
    /// </summary>
    public partial class TimePickDialog : Window
    {
        /// <summary>用户是否点击了"确定"。</summary>
        public bool Confirmed { get; private set; }

        /// <summary>确定后选中的时间。</summary>
        public TimeSpan SelectedTime { get; private set; }

        public TimePickDialog(string title, TimeSpan initial)
        {
            InitializeComponent();
            TitleText.Text = title;
            HourCombo.SelectedItem = initial.Hours;
            MinuteCombo.SelectedItem = initial.Minutes;
        }

        private void Confirm_Click(object sender, RoutedEventArgs e)
        {
            if (HourCombo.SelectedItem is int h && MinuteCombo.SelectedItem is int m)
                SelectedTime = new TimeSpan(h, m, 0);
            Confirmed = true;
            Close();
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
            => Close();

        private void Window_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
                Close();
        }
    }
}
