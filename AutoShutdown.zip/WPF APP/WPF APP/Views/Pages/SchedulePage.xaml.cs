using System.Windows;
using System.Windows.Controls;
using WPF_APP.Models;
using WPF_APP.Services;

namespace WPF_APP.Views.Pages
{
    /// <summary>
    /// 定时设置页（需求 4.3）：周一至周日每日关机时间与启用开关，支持批量设置。
    /// 修改即时写入内存中的 ScheduleService（概览页同步读取，随页面切换刷新）。
    /// </summary>
    public partial class SchedulePage : UserControl
    {
        private readonly ScheduleService _scheduler = ScheduleService.Instance;

        public SchedulePage()
        {
            InitializeComponent();
            DayList.ItemsSource = _scheduler.Days;
        }

        private void BatchAll_Click(object sender, RoutedEventArgs e)
            => ApplyBatch("全部设为同一时间", _ => true);

        private void BatchWeekday_Click(object sender, RoutedEventArgs e)
            => ApplyBatch("工作日统一设置",
                d => d.Day != DayOfWeek.Saturday && d.Day != DayOfWeek.Sunday);

        private void BatchWeekend_Click(object sender, RoutedEventArgs e)
            => ApplyBatch("周末统一设置",
                d => d.Day == DayOfWeek.Saturday || d.Day == DayOfWeek.Sunday);

        private void ApplyBatch(string title, Func<DaySchedule, bool> selector)
        {
            BatchButton.IsChecked = false; // 收起菜单

            var days = _scheduler.Days.Where(selector).ToList();
            if (days.Count == 0) return;

            var dialog = new TimePickDialog(title, days[0].Time) { Owner = Window.GetWindow(this) };
            dialog.ShowDialog();
            if (!dialog.Confirmed) return;

            foreach (var d in days)
                d.Time = dialog.SelectedTime;
        }
    }
}
