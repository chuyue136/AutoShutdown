using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
using WPF_APP.Services;

namespace WPF_APP.Views.Pages
{
    /// <summary>
    /// 概览页（需求 4.2）：下次关机时间 + 实时倒计时（环形进度条）、
    /// 快捷操作（立即关机 / 今日不再关机）、今日状态与本周统计。
    /// </summary>
    public partial class OverviewPage : UserControl
    {
        private const double RingDiameter = 140;
        private const double RingStroke = 8;

        private readonly DispatcherTimer _timer = new() { Interval = TimeSpan.FromSeconds(1) };
        private readonly ScheduleService _scheduler = ScheduleService.Instance;

        private DateTime? _nextShutdown;
        private double _ringCircumference;

        // 状态颜色：等待中=主题蓝，已执行=绿色，已跳过=灰色
        private static readonly Brush StatusWaiting = new SolidColorBrush(Color.FromRgb(0x00, 0x78, 0xD4));
        private static readonly Brush StatusDone = new SolidColorBrush(Color.FromRgb(0x10, 0x7C, 0x10));
        private static readonly Brush StatusSkipped = new SolidColorBrush(Color.FromRgb(0x6B, 0x6B, 0x6B));

        public OverviewPage()
        {
            InitializeComponent();
            _timer.Tick += OnTimerTick;
            Loaded += OnPageLoaded;
            Unloaded += OnPageUnloaded;
        }

        private void OnPageLoaded(object sender, RoutedEventArgs e)
        {
            // 环形进度条：用虚线描边模拟圆环进度（虚线全长 = 圆周长，用偏移量控制进度）
            var radius = (RingDiameter - RingStroke) / 2;
            _ringCircumference = 2 * Math.PI * radius;
            Ring.StrokeDashArray = new DoubleCollection { _ringCircumference, _ringCircumference };
            Ring.StrokeDashOffset = 0;

            RefreshAll();
            _timer.Start();
        }

        private void OnPageUnloaded(object sender, RoutedEventArgs e)
            => _timer.Stop();

        private void OnTimerTick(object? sender, EventArgs e)
            => RefreshCountdown();

        /// <summary>
        /// 每秒刷新：从调度服务读取"下次触发时间"（再提醒等待期、今日跳过、计划修改都会即时反映），
        /// 变化时同步更新时间文本，再更新倒计时。
        /// </summary>
        private void RefreshCountdown()
        {
            var next = SchedulerService.Instance.NextTriggerTime;
            if (next != _nextShutdown)
            {
                _nextShutdown = next;
                UpdateNextTimeText();
            }
            UpdateCountdown();
        }

        private void RefreshAll()
        {
            _nextShutdown = SchedulerService.Instance.NextTriggerTime;
            UpdateNextTimeText();
            UpdateCountdown();
            UpdateStatusCards();
            SyncSkipButton();
        }

        private void UpdateNextTimeText()
        {
            if (_nextShutdown is DateTime t)
            {
                // 例：22:30 · 今天周日
                var dayLabel = t.Date == DateTime.Today
                    ? $"今天{WeekdayLabel(t)}"
                    : WeekdayLabel(t);
                NextTimeText.Text = $"{t:HH:mm} · {dayLabel}";
            }
            else
            {
                NextTimeText.Text = "未设置";
            }
        }

        private void UpdateCountdown()
        {
            if (_nextShutdown is not DateTime t)
            {
                CountdownText.Text = "--:--:--";
                SetRing(0);
                return;
            }

            var remaining = t - DateTime.Now;
            if (remaining < TimeSpan.Zero)
                remaining = TimeSpan.Zero;

            var totalHours = Math.Floor(remaining.TotalHours);
            CountdownText.Text = $"{totalHours:00}:{remaining.Minutes:00}:{remaining.Seconds:00}";

            // 环形进度 = 剩余时间 / 一天（24 小时）
            SetRing(remaining.TotalSeconds / TimeSpan.FromHours(24).TotalSeconds);
        }

        private void SetRing(double progress)
        {
            progress = Math.Clamp(progress, 0, 1);
            Ring.StrokeDashOffset = _ringCircumference * (1 - progress);
        }

        private void UpdateStatusCards()
        {
            var today = _scheduler.GetTodaySchedule();
            bool todayDisabled = today is null || !today.IsEnabled;

            if (_scheduler.ExecutedTodayCount > 0)
            {
                TodayStatusText.Text = "已执行";
                TodayStatusText.Foreground = StatusDone;
                TodayStatusHint.Text = "今天已执行过关机";
            }
            else if (_scheduler.TodaySkipped || todayDisabled)
            {
                TodayStatusText.Text = "已跳过";
                TodayStatusText.Foreground = StatusSkipped;
                TodayStatusHint.Text = todayDisabled ? "今天的关机计划已关闭" : "今天不再触发关机";
            }
            else
            {
                TodayStatusText.Text = "等待中";
                TodayStatusText.Foreground = StatusWaiting;
                TodayStatusHint.Text = today is null
                    ? "未设置计划"
                    : $"按 {today.Time.Hours:00}:{today.Time.Minutes:00} 计划执行";
            }

            WeekCountText.Text = $"{_scheduler.ExecutedThisWeekCount} 次";
        }

        private static string WeekdayLabel(DateTime t)
            => "周" + "日一二三四五六"[(int)t.DayOfWeek];

        // ---- 快捷操作 ----

        private void ShutdownNow_Click(object sender, RoutedEventArgs e)
        {
            // 需求 3.4：二次确认
            var confirm = new ConfirmShutdownWindow { Owner = Window.GetWindow(this) };
            confirm.ShowDialog();
            if (!confirm.Confirmed)
                return;

            if (ShutdownService.ExecuteShutdown())
            {
                _scheduler.RegisterShutdownExecuted(DateTime.Now);
                RefreshAll();
            }
        }

        private void SkipToday_Click(object sender, RoutedEventArgs e)
        {
            if (_scheduler.TodaySkipped)
            {
                // 点击"取消"：取消今日不再关机，恢复当日计划与倒计时
                _scheduler.TodaySkipped = false;
                RefreshAll();
            }
            else
            {
                // 需求 2.4：今日不再关机，当天剩余时间不再触发；
                // 点击后按钮置为不可用，悬停时才显示"取消"
                _scheduler.TodaySkipped = true;
                RefreshAll();
            }
        }

        /// <summary>根据"今日已跳过"状态同步按钮外观：悬停显示"取消"，离开恢复不可用。</summary>
        private void SyncSkipButton()
        {
            if (_scheduler.TodaySkipped)
            {
                if (SkipTodayHost.IsMouseOver)
                    ShowCancelState();
                else
                    HideCancelState();
            }
            else
            {
                SkipTodayButton.IsEnabled = true;
                SkipTodayButton.Content = "今日不再关机";
            }
        }

        private void SkipTodayHost_MouseEnter(object sender, MouseEventArgs e)
        {
            if (_scheduler.TodaySkipped)
                ShowCancelState();
        }

        private void SkipTodayHost_MouseLeave(object sender, MouseEventArgs e)
        {
            if (_scheduler.TodaySkipped)
                HideCancelState();
        }

        private void ShowCancelState()
        {
            SkipTodayButton.IsEnabled = true;
            SkipTodayButton.Content = "取消";
        }

        private void HideCancelState()
        {
            SkipTodayButton.IsEnabled = false;
            SkipTodayButton.Content = "今日不再关机";
        }
    }
}
