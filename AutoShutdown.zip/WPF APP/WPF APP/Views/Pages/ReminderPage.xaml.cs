using System.IO;
using System.Windows;
using System.Windows.Controls;
using WPF_APP.Services;

namespace WPF_APP.Views.Pages
{
    /// <summary>
    /// 提醒设置页（需求 4.4）：再提醒时长、弹窗倒计时、提示音（预设/自定义/音量）。
    /// 修改即时写入内存中的 ReminderService。
    /// </summary>
    public partial class ReminderPage : UserControl
    {
        /// <summary>预设提示音显示名称，与 SoundPreset 枚举顺序一致。</summary>
        public static string[] PresetLabels { get; } =
            { "柔和提示音", "清脆铃声", "电子蜂鸣", "系统默认", "静音" };

        private readonly ReminderService _settings = ReminderService.Instance;

        public ReminderPage()
        {
            InitializeComponent();
            DataContext = _settings;
            Loaded += OnPageLoaded;
        }

        private void OnPageLoaded(object sender, RoutedEventArgs e)
        {
            PresetCombo.SelectedIndex = (int)_settings.SoundPreset;
            AutoStartToggle.IsChecked = AutoStartService.IsEnabled();
            UpdateCustomSoundUI();
        }

        private void AutoStartToggle_Changed(object sender, RoutedEventArgs e)
        {
            // 需求 5.4：写入/删除注册表 Run 键
            if (AutoStartToggle.IsChecked == true)
                AutoStartService.Enable();
            else
                AutoStartService.Disable();
        }

        private void PresetCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (PresetCombo.SelectedIndex >= 0)
                _settings.SoundPreset = (SoundPreset)PresetCombo.SelectedIndex;
        }

        private void QuickReminder_Click(object sender, RoutedEventArgs e)
            => _settings.ReminderMinutes = Convert.ToInt32(((Button)sender).Tag);

        private void QuickCountdown_Click(object sender, RoutedEventArgs e)
            => _settings.CountdownSeconds = Convert.ToInt32(((Button)sender).Tag);

        private void PlayPreview_Click(object sender, RoutedEventArgs e)
            => SoundService.PlayEffective(_settings);

        private void ChooseSound_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new Microsoft.Win32.OpenFileDialog
            {
                Title = "选择提示音",
                Filter = "音频文件 (*.wav;*.mp3)|*.wav;*.mp3|所有文件 (*.*)|*.*"
            };
            if (dialog.ShowDialog(Window.GetWindow(this)) != true) return;

            try
            {
                // 复制到程序配置目录 %AppData%\AutoShutdown\Sounds\
                var soundsDir = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                    "AutoShutdown", "Sounds");
                Directory.CreateDirectory(soundsDir);
                var dest = Path.Combine(soundsDir, Path.GetFileName(dialog.FileName));
                File.Copy(dialog.FileName, dest, overwrite: true);

                _settings.CustomSoundPath = dest;
                UpdateCustomSoundUI();
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show($"复制音频文件失败：{ex.Message}", "自动关机助手",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void RemoveSound_Click(object sender, RoutedEventArgs e)
        {
            _settings.CustomSoundPath = null;
            UpdateCustomSoundUI();
        }

        private void UpdateCustomSoundUI()
        {
            if (string.IsNullOrEmpty(_settings.CustomSoundPath))
            {
                CustomSoundText.Text = "未选择自定义音频";
                RemoveSoundButton.Visibility = Visibility.Collapsed;
            }
            else
            {
                CustomSoundText.Text = Path.GetFileName(_settings.CustomSoundPath);
                RemoveSoundButton.Visibility = Visibility.Visible;
            }
        }
    }
}
