using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Microsoft.Web.WebView2.Wpf;

namespace WPF_APP.Views.Pages
{
    /// <summary>
    /// 关于页（需求 4.5）：WebView2 嵌入本地 Assets\about.html；
    /// 若未安装 WebView2 运行时或页面缺失，降级为纯文本显示版本与作者信息。
    /// </summary>
    public partial class AboutPage : UserControl
    {
        private const string Author = "chuyue136";
        private static readonly Brush SecondaryBrush = new SolidColorBrush(Color.FromRgb(0x6B, 0x6B, 0x6B));

        public AboutPage()
        {
            InitializeComponent();

            var version = Assembly.GetExecutingAssembly().GetName().Version;
            VersionTextBlock.Text = version is null
                ? "v1.0.0"
                : $"v{version.Major}.{version.Minor}.{version.Build}";
            InfoBarText.Text = $"版本 {VersionTextBlock.Text} · 作者 {Author}";

            Loaded += OnPageLoaded;
        }

        private static string HtmlPath
            => Path.Combine(AppContext.BaseDirectory, "Assets", "about.html");

        private WebView2? _webView;

        private void OnPageLoaded(object sender, RoutedEventArgs e)
        {
            // 只创建一次：切换页面/窗口显隐时复用，避免重复创建导致 Edge WebView2 进程泄漏
            if (_webView is null)
                CreateWebView();
        }

        private void CreateWebView()
        {
            if (!File.Exists(HtmlPath))
            {
                ShowFallback("未找到页面文件 Assets\\about.html");
                return;
            }

            try
            {
                _webView = new WebView2
                {
                    DefaultBackgroundColor = System.Drawing.Color.White
                };
                _webView.Source = new Uri(HtmlPath, UriKind.Absolute);
                WebHost.Child = _webView;
            }
            catch (Exception ex)
            {
                _webView = null;
                // WebView2 运行时未安装等情况（需求 4.5：降级为纯文本）
                ShowFallback("无法初始化内置页面（WebView2 运行时可能未安装）。\n" + ex.Message);
            }
        }

        /// <summary>
        /// 释放 WebView2 及其浏览器进程（主窗口隐藏到托盘 / 程序退出时调用），
        /// 防止 Edge WebView2 进程常驻内存。
        /// </summary>
        public void DisposeWebView()
        {
            if (_webView is null) return;
            WebHost.Child = null;
            _webView.Dispose();
            _webView = null;
        }

        private void ShowFallback(string reason)
        {
            var panel = new StackPanel
            {
                HorizontalAlignment = System.Windows.HorizontalAlignment.Center,
                VerticalAlignment = System.Windows.VerticalAlignment.Center
            };
            panel.Children.Add(new TextBlock
            {
                Text = reason,
                FontSize = 14,
                Foreground = SecondaryBrush,
                TextWrapping = TextWrapping.Wrap,
                TextAlignment = TextAlignment.Center,
                Margin = new Thickness(24)
            });
            panel.Children.Add(new TextBlock
            {
                Text = $"版本 {VersionTextBlock.Text} · 作者 {Author}",
                FontSize = 13,
                Foreground = SecondaryBrush,
                TextAlignment = TextAlignment.Center,
                Margin = new Thickness(0, 10, 0, 24)
            });
            WebHost.Child = panel;
        }

        private void OpenInBrowser_Click(object sender, RoutedEventArgs e)
        {
            if (!File.Exists(HtmlPath)) return;
            try
            {
                Process.Start(new ProcessStartInfo(HtmlPath) { UseShellExecute = true });
            }
            catch
            {
                // 打开失败静默处理
            }
        }
    }
}
