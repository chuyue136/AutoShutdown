using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;
using WPF_APP.Services;
using WinForms = System.Windows.Forms;

namespace WPF_APP.Views
{
    /// <summary>
    /// 关机提醒弹窗（需求 1.2 / 1.3 / 1.4 / 第二章）：
    /// 置顶居中、大号倒计时（最后 5 秒变红）、淡入+缩放动画、出现瞬间播放一次提示音；
    /// 三个操作：立即关机 / X 分钟后再提醒 / 今日不再关机；无响应则倒计时结束自动关机。
    /// </summary>
    public partial class ReminderWindow : Window
    {
        public enum ReminderResult { None, Shutdown, Delay, SkipToday }

        /// <summary>用户操作结果，供调度服务决定下一次触发。</summary>
        public ReminderResult Result { get; private set; } = ReminderResult.None;

        private readonly ReminderService _settings = ReminderService.Instance;
        private readonly DispatcherTimer _timer = new() { Interval = TimeSpan.FromSeconds(1) };
        private int _remainingSeconds;

        private static readonly Brush NormalBrush = new SolidColorBrush(Color.FromRgb(0x1B, 0x1B, 0x1B));
        private static readonly Brush DangerBrush = new SolidColorBrush(Color.FromRgb(0xC4, 0x2B, 0x1C));

        public ReminderWindow()
        {
            InitializeComponent();

            _remainingSeconds = _settings.CountdownSeconds;
            DelayButton.Content = $"{_settings.ReminderMinutes} 分钟后再提醒";
            UpdateCountdown();

            Loaded += OnLoaded;
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            // 出现瞬间播放一次提示音（需求 1.3）
            SoundService.PlayEffective(_settings);

            // 淡入 + 轻微缩放（需求 1.4）
            BeginAnimation(OpacityProperty, new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(180)));
            var scale = new DoubleAnimation(0.96, 1, TimeSpan.FromMilliseconds(200))
            {
                EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
            };
            EntryScale.BeginAnimation(ScaleTransform.ScaleXProperty, scale);
            EntryScale.BeginAnimation(ScaleTransform.ScaleYProperty, scale);

            _timer.Tick += OnTick;
            _timer.Start();
        }

        private void OnTick(object? sender, EventArgs e)
        {
            _remainingSeconds--;
            if (_remainingSeconds <= 0)
            {
                // 需求 2.1：无响应，倒计时结束自动关机
                _timer.Stop();
                ShutdownNow();
                return;
            }
            UpdateCountdown();
        }

        private void UpdateCountdown()
        {
            CountdownText.Text = _remainingSeconds.ToString();
            CountdownText.Foreground = _remainingSeconds <= 5 ? DangerBrush : NormalBrush;
        }

        /// <summary>弹窗居中显示在鼠标所在显示器（需求 1.2 / 5.6）。</summary>
        protected override void OnSourceInitialized(EventArgs e)
        {
            base.OnSourceInitialized(e);
            PositionOnMouseMonitor();
        }

        private void PositionOnMouseMonitor()
        {
            var pt = WinForms.Cursor.Position; // 物理像素
            var area = WinForms.Screen.FromPoint(pt).WorkingArea;
            var scale = GetScreenDpiScale(pt);

            // WPF 窗口坐标是逻辑像素（DIP），须按显示器 DPI 换算，否则高分屏下会偏移
            Left = area.Left / scale + (area.Width / scale - Width) / 2.0;
            Top = area.Top / scale + (area.Height / scale - Height) / 2.0;
        }

        private static double GetScreenDpiScale(System.Drawing.Point physicalPoint)
        {
            try
            {
                var hMonitor = MonitorFromPoint(
                    new POINT { X = physicalPoint.X, Y = physicalPoint.Y }, MONITOR_DEFAULTTONEAREST);
                if (GetDpiForMonitor(hMonitor, MDT_EFFECTIVE_DPI, out uint dpiX, out _) == 0 && dpiX > 0)
                    return dpiX / 96.0;
            }
            catch
            {
                // 取不到 DPI 时按 100% 缩放处理
            }
            return 1.0;
        }

        private const uint MONITOR_DEFAULTTONEAREST = 2;
        private const int MDT_EFFECTIVE_DPI = 0;

        [StructLayout(LayoutKind.Sequential)]
        private struct POINT
        {
            public int X;
            public int Y;
        }

        [DllImport("user32.dll")]
        private static extern IntPtr MonitorFromPoint(POINT pt, uint dwFlags);

        [DllImport("shcore.dll")]
        private static extern int GetDpiForMonitor(IntPtr hMonitor, int dpiType, out uint dpiX, out uint dpiY);

        private void ShutdownNow()
        {
            Result = ReminderResult.Shutdown;
            _timer.Stop();
            if (ShutdownService.ExecuteShutdown())
                ScheduleService.Instance.RegisterShutdownExecuted(DateTime.Now);
            Close();
        }

        private void ShutdownNow_Click(object sender, RoutedEventArgs e)
            => ShutdownNow();

        private void Delay_Click(object sender, RoutedEventArgs e)
        {
            // 需求 2.3：关闭弹窗，由调度服务在设定时长后重新弹出
            Result = ReminderResult.Delay;
            _timer.Stop();
            Close();
        }

        private void SkipToday_Click(object sender, RoutedEventArgs e)
        {
            // 需求 2.4：当天剩余时间不再触发，次日恢复
            Result = ReminderResult.SkipToday;
            _timer.Stop();
            ScheduleService.Instance.TodaySkipped = true;
            Close();
        }

        /// <summary>供调度服务在休眠等场景强制关闭弹窗。</summary>
        public void ForceClose(ReminderResult result)
        {
            _timer.Stop();
            Result = result;
            Close();
        }
    }
}
